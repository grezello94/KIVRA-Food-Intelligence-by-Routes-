KIVRA Windows Print Bridge 1.6.0

Upgrade an existing installation:
1. Find KIVRA Print Bridge in the Windows notification area (near the clock).
2. Right-click it and choose Exit.
3. Extract this ZIP and run KIVRA Windows Print Bridge.exe.

Your existing pairing and USB printer settings are kept. The bridge installs
this version for automatic startup at the next Windows sign-in. If it asks for
setup, select the USB label printer and use a pairing code from KIVRA's Print
Bridge settings.

This version checks for labels every 250 ms while idle. Printer discovery runs
in the background so slow Windows spooler discovery does not hold up labels.
The bridge continues running when its status window is hidden.
